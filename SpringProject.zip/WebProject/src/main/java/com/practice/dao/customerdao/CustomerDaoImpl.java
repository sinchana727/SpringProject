package com.practice.dao.customerdao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practice.entity.Customer;
import com.practice.repository.CustomerRepository;
import com.practice.repository.UserRepository;


@Service
public class CustomerDaoImpl implements CustomerDao {

	@AutoWired 
	CustomerRepository customerRepository;
	@Autowired
	UserRepository userRepository;
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		
		List<Customer>  list = customerRepository.findAll();
		return null;
	}
	
	
	

}
