package com.practice.dao.customerdao;

public @interface AutoWired {

}
